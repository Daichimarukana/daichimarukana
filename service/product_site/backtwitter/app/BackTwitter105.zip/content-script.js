window.onload = function(){

    let text = document.querySelector('[viewBox="0 0 24 24"]').innerHTML;
    document.querySelector('[viewBox="0 0 24 24"]').innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" class="r-1cvl2hr r-4qtqp9 r-yyyyoo r-16y2uox r-8kz0gk r-dnmrzs r-bnwqim r-1plcrui r-lrvibr r-lrsllp"><g><path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"></path></g></svg>';
    const head = document.head;
    head.insertAdjacentHTML('beforeEnd', '<link rel="shortcut icon" href="https://abs.twimg.com/favicons/twitter.ico">');

    console.log("鳥化実行！！！")

    setTimeout(() => {;
        let text = document.querySelector('[viewBox="0 0 24 24"]').innerHTML;
        document.querySelector('[viewBox="0 0 24 24"]').innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true" class="r-1cvl2hr r-4qtqp9 r-yyyyoo r-16y2uox r-8kz0gk r-dnmrzs r-bnwqim r-1plcrui r-lrvibr r-lrsllp"><g><path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"></path></g></svg>';


        var elem = document.querySelector('[aria-live="polite"]');
        const head = document.head;
        head.insertAdjacentHTML('beforeEnd', '<link rel="shortcut icon" href="https://abs.twimg.com/favicons/twitter.ico">');
        console.log("鳥化再実行！！！")
    }, 500);

    setTimeout(() => {;
        let text2 = document.querySelector('[class="css-901oao r-1tl8opc r-n6v787 r-16dba41 r-1cwl3u0 r-hrzydr r-bcqeeo r-j2kj52 r-qvutc0"]').innerHTML;
        document.querySelector('[class="css-901oao r-1tl8opc r-n6v787 r-16dba41 r-1cwl3u0 r-hrzydr r-bcqeeo r-j2kj52 r-qvutc0"]').innerHTML = '<span class="css-901oao css-16my406 r-1tl8opc r-bcqeeo r-qvutc0">© 2023 Twitter, Inc.</span>';

        let text3 = document.querySelector('[class="css-1dbjc4n r-xoduu5"]').innerHTML;
        document.querySelector('[class="css-1dbjc4n r-xoduu5"]').innerHTML = '<span>ツイートする</span>';

        let text4 = document.querySelector('[class="css-901oao css-16my406 css-1hf3ou5 r-1tl8opc r-a023e6 r-rjixqe r-bcqeeo r-qvutc0"]').innerHTML;
        document.querySelector('[class="css-901oao css-16my406 css-1hf3ou5 r-1tl8opc r-a023e6 r-rjixqe r-bcqeeo r-qvutc0"]').innerHTML = '<span>ツイートする</span>';

        console.log("鳥化再実行！！！")

    }, 1700);

    setTimeout(() => {;
        let text2 = document.querySelector('[class="css-901oao r-1tl8opc r-n6v787 r-16dba41 r-1cwl3u0 r-hrzydr r-bcqeeo r-j2kj52 r-qvutc0"]').innerHTML;
        document.querySelector('[class="css-901oao r-1tl8opc r-n6v787 r-16dba41 r-1cwl3u0 r-hrzydr r-bcqeeo r-j2kj52 r-qvutc0"]').innerHTML = '<span class="css-901oao css-16my406 r-1tl8opc r-bcqeeo r-qvutc0">© 2023 Twitter, Inc.</span>';

        let text3 = document.querySelector('[class="css-1dbjc4n r-xoduu5"]').innerHTML;
        document.querySelector('[class="css-1dbjc4n r-xoduu5"]').innerHTML = '<span>ツイートする</span>';

        let text4 = document.querySelector('[class="css-901oao css-16my406 css-1hf3ou5 r-1tl8opc r-a023e6 r-rjixqe r-bcqeeo r-qvutc0"]').innerHTML;
        document.querySelector('[class="css-901oao css-16my406 css-1hf3ou5 r-1tl8opc r-a023e6 r-rjixqe r-bcqeeo r-qvutc0"]').innerHTML = '<span>ツイートする</span>';

        let text5 = document.querySelector('[href="/i/verified-choose"]').innerHTML;
        document.querySelector('[href="/i/verified-choose"]').innerHTML = '<div class="css-1dbjc4n r-1awozwy r-sdzlij r-18u37iz r-1777fci r-dnmrzs r-xyw6el r-o7ynqc r-6416eg"><div class="css-1dbjc4n"><svg viewBox="0 0 22 22" aria-hidden="true" class="r-18jsvk2 r-4qtqp9 r-yyyyoo r-lwhw9o r-dnmrzs r-bnwqim r-1plcrui r-lrvibr r-cnnz9e"><g><path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z"></path></g></svg></div><div dir="ltr" class="css-901oao css-1hf3ou5 r-18jsvk2 r-1tl8opc r-adyw6z r-16dba41 r-135wba7 r-1joea0r r-88pszg r-bcqeeo r-qvutc0"><span class="css-901oao css-16my406 r-1tl8opc r-bcqeeo r-qvutc0">認証済み</span></div></div>';

        console.log("鳥化再実行！！！")
        console.log("注意:Twitter側のロード状況により鳥化に失敗する場合があります！もしダメだった時はTwitterを再読み込みしてください！")

    }, 3000);

}