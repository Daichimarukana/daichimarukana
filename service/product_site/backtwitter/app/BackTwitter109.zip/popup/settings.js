document.addEventListener('DOMContentLoaded', function() {
    chrome.storage.local.get(["redirect_twitter"]).then((result) => {
        if(result.redirect_twitter == "false"){
            document.getElementById('redirect_twitter').checked = false;
        }else{
            document.getElementById('redirect_twitter').checked = true;
        }
    });

    function save() {
        if(document.getElementById('redirect_twitter').checked){
            chrome.storage.local.set({"redirect_twitter": "true"},function(){
                console.log("save_done");
            });
        }else{
            chrome.storage.local.set({"redirect_twitter": "false"},function(){
                console.log("save_done");
            });
        }
    }

    var checkbox = document.getElementById('redirect_twitter');

    checkbox.addEventListener('change', save);
});