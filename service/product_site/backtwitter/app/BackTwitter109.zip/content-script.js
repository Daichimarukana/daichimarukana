function getGreatGrandchild(element, depth) {
    if (depth === 0) return element;
    if(element.children.length){
        for (let i = 0; i < element.children.length; i++) {
            let result = getGreatGrandchild(element.children[i], depth - 1);
            if (result) return result;
        }
    }
    return null;
}

if(document.querySelector('[aria-label="X"]')){
    document.querySelector('[aria-label="X"]').innerHTML = '<div dir="ltr" class="css-1rynq56 r-bcqeeo r-qvutc0 r-1tl8opc r-q4m81j r-a023e6 r-rjixqe r-b88u0q r-1awozwy r-6koalj r-18u37iz r-16y2uox r-1777fci"><svg viewBox="0 0 24 24" aria-hidden="true" class="r-1cvl2hr r-4qtqp9 r-yyyyoo r-16y2uox r-8kz0gk r-dnmrzs r-bnwqim r-1plcrui r-lrvibr r-lrsllp"><g><path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"></path></g></svg></div>';
}

chrome.storage.local.get(["redirect_twitter"]).then((result) => {
    if(result.redirect_twitter == "true"){
        if(!(window.location.host == "twitter.com" || window.location.host == "www.twitter.com")){
            window.location.href = "https://twitter.com"+window.location.pathname+window.location.search+"?mx=1"
        }
    }
});

const head = document.head;
head.insertAdjacentHTML('beforeEnd', '<link rel="shortcut icon" href="https://abs.twimg.com/favicons/twitter.ico">');

console.log("鳥化実行！！！\n仕様上1秒に一回再鳥化を行っております！ご了承ください！")

    setInterval(function(){

        if(document.querySelector('[aria-label="X"]')){
            document.querySelector('[aria-label="X"]').innerHTML = '<div dir="ltr" class="css-1rynq56 r-bcqeeo r-qvutc0 r-1tl8opc r-q4m81j r-a023e6 r-rjixqe r-b88u0q r-1awozwy r-6koalj r-18u37iz r-16y2uox r-1777fci"><svg viewBox="0 0 24 24" aria-hidden="true" class="r-1cvl2hr r-4qtqp9 r-yyyyoo r-16y2uox r-8kz0gk r-dnmrzs r-bnwqim r-1plcrui r-lrvibr r-lrsllp"><g><path d="M23.643 4.937c-.835.37-1.732.62-2.675.733.962-.576 1.7-1.49 2.048-2.578-.9.534-1.897.922-2.958 1.13-.85-.904-2.06-1.47-3.4-1.47-2.572 0-4.658 2.086-4.658 4.66 0 .364.042.718.12 1.06-3.873-.195-7.304-2.05-9.602-4.868-.4.69-.63 1.49-.63 2.342 0 1.616.823 3.043 2.072 3.878-.764-.025-1.482-.234-2.11-.583v.06c0 2.257 1.605 4.14 3.737 4.568-.392.106-.803.162-1.227.162-.3 0-.593-.028-.877-.082.593 1.85 2.313 3.198 4.352 3.234-1.595 1.25-3.604 1.995-5.786 1.995-.376 0-.747-.022-1.112-.065 2.062 1.323 4.51 2.093 7.14 2.093 8.57 0 13.255-7.098 13.255-13.254 0-.2-.005-.402-.014-.602.91-.658 1.7-1.477 2.323-2.41z"></path></g></svg></div>';
        }

        const head = document.head;
        head.insertAdjacentHTML('beforeEnd', '<link rel="shortcut icon" href="https://abs.twimg.com/favicons/twitter.ico">');

        if(document.querySelector('[aria-label="ポストする"]')){
            document.querySelector('[aria-label="ポストする"]').innerHTML = '<div dir="ltr" class="css-1rynq56 r-bcqeeo r-qvutc0 r-1tl8opc r-q4m81j r-a023e6 r-rjixqe r-b88u0q r-1awozwy r-6koalj r-18u37iz r-16y2uox r-1777fci" style="color: rgb(255, 255, 255); text-overflow: unset;"><span class="css-1qaijid r-dnmrzs r-1udh08x r-3s2u2q r-bcqeeo r-qvutc0 r-1tl8opc r-1inkyih r-rjixqe" style="text-overflow: unset;"><div style=""><div class="css-175oi2r r-xoduu5"><span class="css-1qaijid r-bcqeeo r-qvutc0 r-1tl8opc" style="text-overflow: unset;"><span class="css-1qaijid r-bcqeeo r-qvutc0 r-1tl8opc" style="text-overflow: unset;">ツイートする</span></span></div></div></span></div>';
        }

        if(document.querySelector('[href="/i/premium_sign_up"]')){
            var ifcolor = document.querySelector("body");
            var color = window.getComputedStyle(ifcolor, '').backgroundColor;
            if(color == "rgb(0, 0, 0)" || color == "rgb(21, 32, 43)"){
                document.querySelector('[href="/i/premium_sign_up"]').innerHTML = '<div class="css-175oi2r r-sdzlij r-dnmrzs r-1awozwy r-18u37iz r-1777fci r-xyw6el r-o7ynqc r-6416eg"><div class="css-175oi2r"><svg viewBox="0 0 22 22" aria-hidden="true" class="r-4qtqp9 r-yyyyoo r-dnmrzs r-bnwqim r-lrvibr r-m6rgpd r-1nao33i r-lwhw9o r-cnnz9e"><g><path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z"></path></g></svg></div><div dir="ltr" class="css-146c3p1 r-dnmrzs r-1udh08x r-3s2u2q r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc r-adyw6z r-135wba7 r-16dba41 r-dlybji r-nazi8o" style="text-overflow: unset; color: rgb(247, 249, 249);"><span class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc" style="text-overflow: unset;">認証済み</span></div></div>';
            }else{
                document.querySelector('[href="/i/premium_sign_up"]').innerHTML = '<div class="css-175oi2r r-sdzlij r-dnmrzs r-1awozwy r-18u37iz r-1777fci r-xyw6el r-o7ynqc r-6416eg"><div class="css-175oi2r"><svg viewBox="0 0 22 22" aria-hidden="true" class="r-4qtqp9 r-yyyyoo r-dnmrzs r-bnwqim r-lrvibr r-m6rgpd r-18jsvk2 r-lwhw9o r-cnnz9e"><g><path d="M20.396 11c-.018-.646-.215-1.275-.57-1.816-.354-.54-.852-.972-1.438-1.246.223-.607.27-1.264.14-1.897-.131-.634-.437-1.218-.882-1.687-.47-.445-1.053-.75-1.687-.882-.633-.13-1.29-.083-1.897.14-.273-.587-.704-1.086-1.245-1.44S11.647 1.62 11 1.604c-.646.017-1.273.213-1.813.568s-.969.854-1.24 1.44c-.608-.223-1.267-.272-1.902-.14-.635.13-1.22.436-1.69.882-.445.47-.749 1.055-.878 1.688-.13.633-.08 1.29.144 1.896-.587.274-1.087.705-1.443 1.245-.356.54-.555 1.17-.574 1.817.02.647.218 1.276.574 1.817.356.54.856.972 1.443 1.245-.224.606-.274 1.263-.144 1.896.13.634.433 1.218.877 1.688.47.443 1.054.747 1.687.878.633.132 1.29.084 1.897-.136.274.586.705 1.084 1.246 1.439.54.354 1.17.551 1.816.569.647-.016 1.276-.213 1.817-.567s.972-.854 1.245-1.44c.604.239 1.266.296 1.903.164.636-.132 1.22-.447 1.68-.907.46-.46.776-1.044.908-1.681s.075-1.299-.165-1.903c.586-.274 1.084-.705 1.439-1.246.354-.54.551-1.17.569-1.816zM9.662 14.85l-3.429-3.428 1.293-1.302 2.072 2.072 4.4-4.794 1.347 1.246z"></path></g></svg></div><div dir="ltr" class="css-146c3p1 r-dnmrzs r-1udh08x r-3s2u2q r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc r-adyw6z r-135wba7 r-16dba41 r-dlybji r-nazi8o" style="text-overflow: unset; color: rgb(15, 20, 25);"><span class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc" style="text-overflow: unset;">認証済み</span></div></div>';
            }
        }

        if(document.querySelector('[data-testid="pillLabel"]')){
            document.querySelector('[data-testid="pillLabel"]').innerHTML = '<span class="css-1qaijid r-bcqeeo r-qvutc0 r-1tl8opc" style="text-overflow: unset;"><span class="css-1qaijid r-bcqeeo r-qvutc0 r-1tl8opc" style="text-overflow: unset;"><span class="css-1qaijid r-bcqeeo r-qvutc0 r-1tl8opc" style="text-overflow: unset;">さんがツイートしました</span></span></span>';
        }

        if(document.querySelector('[data-testid="toolBar"]')){
            if(document.querySelector('[data-testid="tweetButtonInline"]')){
                if(document.querySelector('[data-testid="tweetButtonInline"]').textContent == "ポストする"){
                    document.querySelector('[data-testid="tweetButtonInline"]').innerHTML = '<div dir="ltr" class="css-1rynq56 r-bcqeeo r-qvutc0 r-1tl8opc r-q4m81j r-a023e6 r-rjixqe r-b88u0q r-1awozwy r-6koalj r-18u37iz r-16y2uox r-1777fci" style="text-overflow: unset; color: rgb(255, 255, 255);"><span class="css-1qaijid r-dnmrzs r-1udh08x r-3s2u2q r-bcqeeo r-qvutc0 r-1tl8opc r-a023e6 r-rjixqe" style="text-overflow: unset;"><span class="css-1qaijid r-bcqeeo r-qvutc0 r-1tl8opc" style="text-overflow: unset;">ツイートする</span></span></div>';
                }
            }    
        }

        //プロフエラーのテキストをポストからツイートに変える
        if(document.querySelector('[data-testid="empty_state_header_text"]')){
            document.querySelector('[data-testid="empty_state_header_text"]').innerHTML = document.querySelector('[data-testid="empty_state_header_text"]').innerHTML.replace(/ポスト/g, 'ツイート');
        }
        if(document.querySelector('[data-testid="empty_state_body_text"]')){
            document.querySelector('[data-testid="empty_state_body_text"]').innerHTML = document.querySelector('[data-testid="empty_state_body_text"]').innerHTML.replace(/ポスト/g, 'ツイート');
        }
        //プロフ上、変更
        if(document.querySelector('[class="css-146c3p1 r-dnmrzs r-1udh08x r-3s2u2q r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc r-n6v787 r-1cwl3u0 r-16dba41"]')){
            document.querySelector('[class="css-146c3p1 r-dnmrzs r-1udh08x r-3s2u2q r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc r-n6v787 r-1cwl3u0 r-16dba41"]').innerHTML = document.querySelector('[class="css-146c3p1 r-dnmrzs r-1udh08x r-3s2u2q r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc r-n6v787 r-1cwl3u0 r-16dba41"]').innerHTML.replace(/ポスト/g, 'ツイート');
        }

        //ツイ上、変更
        if(document.querySelector('[class="css-175oi2r r-1habvwh"]')){
            if(document.querySelector('[class="css-175oi2r r-1h3ijdo r-1e5uvyk r-6026j"]')){
                var child1 = getGreatGrandchild(document.querySelector('[class="css-175oi2r r-1h3ijdo r-1e5uvyk r-6026j"]'), 1);
                var child2 = child1.children[1];
                if(getGreatGrandchild(child2, 3)){
                    getGreatGrandchild(child2, 3).innerHTML = getGreatGrandchild(child2, 3).innerHTML.replace(/ポスト/g, 'ツイート');
                }
            }else if(document.querySelector('[class="css-175oi2r r-1h3ijdo r-1e5uvyk r-ii8lfi"]')){
                var child1 = getGreatGrandchild(document.querySelector('[class="css-175oi2r r-1h3ijdo r-1e5uvyk r-ii8lfi"]'), 1);
                var child2 = child1.children[1];
                if(getGreatGrandchild(child2, 3)){
                    getGreatGrandchild(child2, 3).innerHTML = getGreatGrandchild(child2, 3).innerHTML.replace(/ポスト/g, 'ツイート');
                }
            }
        }

        //Xでライブ配信を...
        if(document.querySelector('[class="css-175oi2r r-1wtj0ep r-1mmae3n r-3pj75a r-1ny4l3l"]')){
            if(document.querySelector('[class="css-175oi2r r-1wtj0ep r-1mmae3n r-3pj75a r-1ny4l3l"]')){
                var child1 = getGreatGrandchild(document.querySelector('[class="css-175oi2r r-1wtj0ep r-1mmae3n r-3pj75a r-1ny4l3l"]'), 1);
                var child2 = child1.children[1];
                getGreatGrandchild(child2, 1).innerHTML = getGreatGrandchild(child2, 1).innerHTML.replace(/X/g, 'Twitter');
            }
        }

        //Trends
        if(document.querySelectorAll('[class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc"]')){
            if(document.querySelectorAll('[class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc"]')){
                for (let i = 0; i < document.querySelectorAll('[class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc"]').length; i++) {
                    document.querySelectorAll('[class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc"]')[i].innerHTML = document.querySelectorAll('[class="css-1jxf684 r-bcqeeo r-1ttztb7 r-qvutc0 r-1tl8opc"]')[i].innerHTML.replace(/posts/g, '件のツイート');
                };
            }
        }

        if(document.querySelector('[href="https://tweetdeck.twitter.com"]')){
            const baby = document.querySelector('[href="https://tweetdeck.twitter.com"]').firstElementChild
            const last_baby = baby.lastElementChild
            const mago_baby = last_baby.firstElementChild
            if(mago_baby.textContent == "Pro"){
                last_baby.innerHTML = '<span class="css-1qaijid r-bcqeeo r-qvutc0 r-1tl8opc" style="text-overflow: unset;">TweetDeck</span>'
            }
        }

        if(document.querySelector('[aria-label*=件の未読項目]')){
            const head = document.head;
            head.insertAdjacentHTML('beforeEnd', '<link rel="shortcut icon" href="https://abs.twimg.com/favicons/twitter-pip.ico">');
        }else{
            const head = document.head;
            head.insertAdjacentHTML('beforeEnd', '<link rel="shortcut icon" href="https://abs.twimg.com/favicons/twitter.ico">');
        }

        if(document.querySelector('[aria-label="プレミアムにサブスクライブ"]')){
            var premium_element = document.querySelector('[aria-label="プレミアムにサブスクライブ"]');
            parent = premium_element.parentNode
            parent.remove();
        }

        if(document.querySelector('[data-testid="inlinePrompt"]')){
            var subscribe_element = document.querySelector('[data-testid="inlinePrompt"]');
            parent = subscribe_element.parentNode
            parent.remove();
        }

        if(document.getElementsByTagName("title")){
            let title_element = document.getElementsByTagName("title");
            if(title_element[0]){
                var new_html_word = title_element[0].innerHTML.replace(/X/g, 'Twitter');;
                title_element[0].innerHTML = ''+new_html_word+'';
            }
        }
        
    }, 1000);

    console.log("BackTwitter - 2024")
