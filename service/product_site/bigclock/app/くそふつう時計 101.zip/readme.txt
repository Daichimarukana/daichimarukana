----------
くそふつう時計
制作者 : だいちまる
制作年月日 : 2023/01/30
最終更新日 : 2023/02/25
Version 1.0.1
(c)2022 - 2023 Daichimaru
Twitter @daichimarukana
----------
[・]はじめに
この度はだめみくじをダウンロードしてくださりありがとうございます！
このソフトを使うにあたっていくつかお願いがあるのでこのtxtファイルはしっかりと読んでいただけるようお願いいたします。
また、なにかしら問題があった場合すぐに公開を停止いたします。

[・]このソフトについて
もともとAndroid向けに配信していた時計アプリですがWindows版もなんか出したほうがいいかもって思って出したアプリです。
これといってくそでかいわけでもないのでこの名前にしました。

[・]Android版との違い
・ウィンドウサイズ
・地震情報機能
・フォント
・対応OS
・ウィンドウ最前面固定機能

[・]使い方
起動する際に「WindowsによってPCが保護されました」と表示されてソフトが起動できない場合があります。
そのような場合は青いウィンドウ内の「詳細情報」を押していただき、「実行」を押してください。
そうするとソフトを起動することができます。

起動しますと早速時計が表示されます。
左の枠内に年月日、曜日、時
右の枠内に分、地震情報が表示されます。
地震情報は地震情報が発信されてから約一分間の間表示されます。(多分)

ウィンドウ内で左クリックしますとウィンドウ最前面固定、もう一度左クリックで固定解除します。
Escキーでアプリについての表示がされます。こちらももう一度Escキーを押して解除となります。

時計の表示は24時間表示のみです。
地震情報は一分間に一回更新されます。

地震情報取得の設定は同フォルダ内のsettings.txt内の2行目にて設定できます。
1で利用、0で利用しない設定となります。
設定適用にはアプリの再起動が必要です。
地震情報取得にはインターネットへの接続が必要です。通信料金等は自己負担とさせていただきます。(24時間で約2.88MB)

[・]利用データ
・hspinet.dll - P2P地震情報 JSON API v2からのデータ取得に利用
・hspinet.as - P2P地震情報 JSON API v2からのデータ取得に利用
・hsp3utf.as - アプリのUTF-8対応に利用
・P2P地震情報 JSON API v2 - 地震情報取得のために利用
・気象庁データ - 地震情報取得のために利用
・その他PCの時刻データ、OSのバージョン情報等を利用しています。

[・]ライセンス
P2P地震速報 JSON API v2
----------https://www.p2pquake.net/secondary_use/
気象庁 地震情報・津波予報データ:CC BY 4.0 準拠です。気象庁の情報を利用している旨の表示が必要です。
無保証です。利用によるいかなる損害についても、一切の責任を負いません。また、情報の正確性も一切保証しません。
----------
hspinet.dll
----------http://www.onionsoft.net/hsp/v33/doclib/hspinet.txt
OpenHSP Copyright (c) 1997-2012, Onion Software/onitama.
  NKF Copyright (C) 1987, FUJITSU LTD. (I.Ichikawa).
  NKF Copyright (C) 1996-2009, The nkf Project.
  cJSON Copyright (c) 2009 Dave Gamble
 
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files (the "Software"), to deal
  in the Software without restriction, including without limitation the rights
  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
  copies of the Software, and to permit persons to whom the Software is
  furnished to do so, subject to the following conditions:
 
  The above copyright notice and this permission notice shall be included in
  all copies or substantial portions of the Software.
 
  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
  THE SOFTWARE.

BSDライセンスです。
----------

[・]推奨動作環境
OS : Windows 10 バージョン1809以上のWindows 10,Windows 11
画面サイズ : 1280x720以上
空き容量 : 1MB以上
保存メディア : SSD,HDD,USBメモリー,SDカード,MicroSDカード,3.5インチFDD,DVD,CD

[・]利用規約
二次配布はおやめください。
商用、非商用問わず0円でご利用いただけます。
ソースコードは2023/01/31現在公開しておりませんので改造等はおやめください。
公序良俗に反する、犯罪を助長させるような使い方はおやめください。
何か損害が発生した場合、だいちまるは一切保証しません
利用データの提供元の方々へのクレーム等はおやめください。
ほかに何かございましたらTwitterのDMかDiscordのDMでご連絡ください。
当規約は予告なしに変更する場合がございます。
また、くそふつう時計には常に最新の規約が適用されるものとします。

[・]更新履歴
1.0.0 - 2023/01/30
公開版
1.0.1 - 2023/02/25
地震情報が表示されないバグを修正

[・]その他
開発時に使用したソフトウェア
・Windows 11
・Android 12
・HSP 3.5
・HSP 3.6
・hsp3dish
・Windows メモ帳 11.2210.5.0
・Google Chrome

だいちまるのサイト : https://daichimarukana.com/
だいちまるのYouTube : https://www.youtube.com/channel/UCkilmFnwB_3pSMFsey6ZKrA
だいちまるのTwitter : https://twitter.com/daichimarukana